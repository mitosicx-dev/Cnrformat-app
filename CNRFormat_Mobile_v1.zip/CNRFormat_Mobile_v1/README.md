# CNRFormat Mobile — Phase 2 PWA v1.0

A **working, static, offline-first mobile deck builder** for the user's custom Yu-Gi-Oh! CNR Format. No server-side secrets, build system, npm dependencies, or Termux required during normal use. Install from an HTTPS site such as GitHub Pages. **This is an initial build, not a certified competitive rules simulator.**

## Android setup via GitHub Pages (no PC required)

1. On your Android phone, download `CNRFormat_Mobile_v1.zip` and extract it with Files / My Files. The files inside the extracted folder are the website root.
2. Sign into [github.com](https://github.com) from Chrome (using **Desktop site** may be easier). Create a new **public** repository named `cnrformat-app`, choosing the `main` branch (a README is fine).
3. In the repository's file browser, choose **Add file → Upload files**. Upload the **contents** of the extracted `CNRFormat_Mobile_v1` folder, preserving these paths: `index.html`, `app.js`, `db.js`, `logic.js`, `styles.css`, `sw.js`, `manifest.webmanifest`, `assets/icon-192.png`, `assets/icon-512.png`, `data/catalog_seed.json`, `data/cnr_rules.json`. GitHub's web uploader may not preserve folder structures from every Android file picker; use GitHub's `Create new file` and enter `assets/...` or `data/...` if necessary. `.nojekyll` is optional.
4. Go to repository **Settings → Pages → Build and deployment → Source: Deploy from a branch → Branch: main → /(root) → Save**. Wait until GitHub displays a site URL.
5. Open the deployed URL (typically `https://YOUR_USERNAME.github.io/cnrformat-app/`) in Chrome. In **Rules & Sync**, press **Sync database** while connected to Wi-Fi. This downloads YGOPRODeck v7 card data into the phone's IndexedDB, and after the first sync you can search offline.
6. In Chrome's three-dot menu, use **Add to Home screen** or **Install app**. You may also see an install icon in the app header.

Important: GitHub Pages does not deploy a `.zip` archive by itself; files must be extracted and uploaded as actual files in the repository. Pages sites are public. The app stores your drafts and downloaded cards **locally on your phone**, not in GitHub.

## Local computer alternative

From within the app folder:

```sh
python -m http.server 8000
```

Open `http://localhost:8000/`. Service workers work on HTTPS or localhost. Opening `index.html` directly via `file://` does not work because it loads local JSON with `fetch` and uses browser storage.

## App features

- Offline-first card catalog; bundles 17 Phase 1 seed records, not the complete card pool.
- Full catalog sync directly from `https://db.ygoprodeck.com/api/v7/cardinfo.php` and optional set metadata from `/cardsets.php`; API data resides in IndexedDB, not hardcoded JS. Network access and working CORS are required for in-browser sync. If direct CORS/network access is blocked, import a previously downloaded raw API JSON file instead.
- Search by card name, text, archetype and type; filters for legality and type.
- Category bans (Link, Pendulum, reviewed hand traps/Link-related cards), Oct 19 2026 TCG list and named CNR restrictions; CNR hand trap exceptions. **Cards missing full verification show REVIEW, not LEGAL.**
- Main Deck 40–60, Extra Deck maximum 20, no Side Deck, max 3 copies per card subject to restrictions. Includes CNR 10,000 LP and empty-hand draw rule documentation.
- Save snapshots of decks, recover current draft, export/import backups.
- YDK import/export and YDKE link import/export. Unknown imported IDs are preserved with `Unknown ID` placeholders and can resolve on the next successful catalog sync.
- Card passcodes are required for valid YDK/YDKE export; seed-only records without passcodes will be blocked until full sync.
- Installable PWA with offline application-shell caching; downloaded full card database stays in local IndexedDB until device/browser data is cleared.

## Important limitations (read before relying on legality)

- The CNR ruleset is the provisional **2026-10-21** Phase 1 snapshot, with official TCG list effective **2026-10-19**. This app does **not** update the CNR restrictions when the YGOPRODeck card database updates. A card released after Oct 21 is blocked until the CNR rules snapshot is intentionally updated.
- CNR has a broad **hand trap** and **Link-related** ban. Imported cards default to **unreviewed** for those subjective categories unless present in the 17 manually reviewed seed classifications. It is deliberately unsafe to certify the full pool simply by inspecting effect text.
- Imported card release dates are sourced from API miscellaneous information or set-level `tcg_date` metadata where available. Unknown dates remain **REVIEW**. This may produce large review queues; it is conservative by design.
- An API sync depends on the external service's availability, CORS settings, connection size and local storage quota. A failed or partial sync is reported. Existing data already saved is preserved when parsing fails; a mid-save storage error may leave some new records while keeping old records. There is no guarantee of perpetual offline persistence (Android browser data can be cleared).
- Does **not** simulate actual duel rules, verify individual combos, have card images, or run AI deck optimization. Those are future phases.
- A published public website does not make proprietary game artwork available for unrestricted redistribution. We intentionally show locally drawn placeholder card graphics. YGOPRODeck explicitly discourages image hotlinking: https://ygoprodeck.com/api-guide/ .
- Main/Extra Deck zone detection follows card `type` metadata. Imported unknown IDs cannot be zone-verified until catalog sync.

## Source and attribution

- YGOPRODeck API guide: https://ygoprodeck.com/api-guide/
- Konami official Oct 19 2026 list: https://www.yugioh-card.com/en/limited/list_2026-10-19/
- GitHub Pages instructions: https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site

## Internal structure

- `data/cnr_rules.json` — unmodified Phase 1 rules with the complete 256 restriction entries, provisional category dictionary and copy precedence.
- `data/catalog_seed.json` — 17 reviewed seed card records (without verified IDs).
- `logic.js` — pure legality audit, imports, exports, status classification, API normalization.
- `db.js` — IndexedDB card storage.
- `app.js` — app UI, library persistence, card sync and action wiring.
- `sw.js` and `manifest.webmanifest` — offline shell and PWA installation.
- `tests/test_logic.js` — automated local test script.

To run tests: `node tests/test_logic.js` from repository root.

## Optional: automatic weekly card-data publishing

The included `.github/workflows/sync-card-snapshot.yml` runs on repository setup, on manual request, and every Sunday. It downloads the current API once, builds a compact `data/card_snapshot.json`, and commits it into your public repo if it changed. If you upload `.github/workflows/sync-card-snapshot.yml` and `scripts/build_snapshot.py` with the rest of the website files, GitHub Actions can keep your **same-origin** card snapshot updated without requiring Termux. GitHub may require enabling **Settings → Actions → General → Workflow permissions → Read and write permissions**. If Actions are disabled or the runner encounters the API/network error, the app still works with bundled seed data and any cached records.

When you tap **Sync database**, the app first attempts the direct live API; if that fails (for example, CORS), it automatically tries `./data/card_snapshot.json` from your GitHub Pages site. The GitHub action is recommended for reliability. It updates **card records**, never your CNR custom rules.

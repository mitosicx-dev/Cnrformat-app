#!/usr/bin/env python3
"""GitHub Actions-only updater. Pull card/set data once and publish same-origin JSON.
No tokens, secrets or user content are sent to the API.
"""
import json, os, urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
API='https://db.ygoprodeck.com/api/v7/'
HEADERS={'User-Agent':'CNRFormat-Mobile-PWA/1.0 (weekly static snapshot; contact via repository)'}

def get(path):
    with urllib.request.urlopen(urllib.request.Request(API+path,headers=HEADERS),timeout=120) as r:
        return json.load(r)

def build(raw,sets):
    data=raw.get('data') if isinstance(raw,dict) else raw
    if not isinstance(data,list) or len(data)<1000:
        raise ValueError('Expected full API response of 1000+ cards; refusing to overwrite snapshot')
    if not isinstance(sets,list) or len(sets)<100:
        raise ValueError('Set metadata unavailable/incomplete; refusing to overwrite snapshot')
    cards=[]
    for c in data:
        if not c.get('name') or not c.get('type') or c.get('id') is None:
            raise ValueError('Malformed card record; refusing snapshot update')
        misc=c.get('misc_info')
        if isinstance(misc,list): misc=misc[0] if misc else None
        cc={k:c[k] for k in ('id','name','type','desc','archetype','race','attribute','level','atk','def','frameType') if k in c}
        if isinstance(misc,dict) and misc.get('tcg_date'):cc['misc_info']={'tcg_date':misc['tcg_date']}
        if c.get('card_sets'):
            cc['card_sets']=[{'set_name':s['set_name']} for s in c['card_sets'] if isinstance(s,dict) and s.get('set_name')]
        cards.append(cc)
    cards.sort(key=lambda c:c['name'].casefold())
    kept_sets=[{k:s[k] for k in ('set_name','tcg_date') if k in s} for s in sets if s.get('set_name')]
    kept_sets.sort(key=lambda s:s['set_name'].casefold())
    return {'source':'YGOPRODeck v7','data':cards,'sets':kept_sets}

def main():
    print('Requesting full card catalog from YGOPRODeck API v7')
    payload=build(get('cardinfo.php'),get('cardsets.php'))
    dest=ROOT/'data'/'card_snapshot.json'
    content=json.dumps(payload,ensure_ascii=False,separators=(',',':')).encode('utf8')
    if dest.exists() and dest.read_bytes()==content:
        print('No changes; preserving existing snapshot');return
    temp=dest.with_suffix('.tmp');temp.write_bytes(content);os.replace(temp,dest)
    print(f'Wrote {len(payload["data"]):,} cards and {len(payload["sets"]):,} sets ({len(content):,} bytes)')
if __name__=='__main__': main()

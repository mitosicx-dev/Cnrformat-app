from pathlib import Path
from urllib.parse import urlparse,unquote
import mimetypes
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'],headless=True)
 for width,height in [(390,844),(1320,900)]:
  ctx=browser.new_context(viewport={'width':width,'height':height},is_mobile=(width<500),has_touch=(width<500),service_workers='block')
  def serve(route):
   rel=unquote(urlparse(route.request.url).path).lstrip('/') or 'index.html'
   f=root/rel
   if not f.is_file():return route.fulfill(status=404,body='Not found')
   typ=mimetypes.guess_type(str(f))[0] or 'application/octet-stream'
   route.fulfill(status=200,body=f.read_bytes(),content_type=typ,headers={'access-control-allow-origin':'*'})
  ctx.route('https://cnr.test/**',serve)
  page=ctx.new_page()
  errors=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto('https://cnr.test/',wait_until='domcontentloaded')
  page.wait_for_function("document.querySelector('#stat-cards').textContent !== '—'",timeout=15000)
  print(width,'initial stats cards=',page.locator('#stat-cards').inner_text(),'errors=',errors)
  assert page.locator('#stat-cards').inner_text()=='17'
  page.locator('#card-search').fill('Raigeki')
  page.wait_for_timeout(320)
  assert 'Raigeki' in page.locator('#card-results').inner_text()
  page.locator('[data-add="raigeki"]').first.click()
  page.locator('.bottom-nav [data-view="builder"]' if width<500 else '.side-nav [data-view="builder"]').click()
  assert page.locator('#zone-main').get_by_text('Raigeki').count()==1
  assert page.locator('#main-count').inner_text().startswith('1')
  page.locator('#save-deck').click()
  page.locator('.bottom-nav [data-view="library"]' if width<500 else '.side-nav [data-view="library"]').click()
  assert page.locator('.saved-card').count()==1
  page.screenshot(path=str(root/'tests'/f'screenshot_{width}.png'),full_page=True)
  print(width,'saved deck and screenshot pass. errors=',errors)
  assert not errors,errors
  ctx.close()
 browser.close()

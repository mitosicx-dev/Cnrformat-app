'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const L=require('../logic.js');
const rules=JSON.parse(fs.readFileSync(path.join(__dirname,'../data/cnr_rules.json')));
const seed=JSON.parse(fs.readFileSync(path.join(__dirname,'../data/catalog_seed.json')));
const idx=L.createIndex(rules);
let total=0;function t(name,fn){try{fn();total++;process.stdout.write('✓ '+name+'\n');}catch(e){console.error('✗ '+name);throw e;}}
const card=(name,more={})=>({key:L.nameKey(name),id:12345,name,type:'Effect Monster',released:true,reviewed:true,categories:[],...more});
const c=(name,other={})=>card(name,other);
const status=x=>L.checkCard(x,idx);
const library=[
 c('Raigeki',{type:'Spell Card'}),
 c('Ame no Habakiri no Mitsurugi',{type:'Ritual Effect Monster'}),
 c('Decode Talker',{type:'Link Monster'}),
 c('Odd-Eyes Pendulum Dragon',{type:'Pendulum Effect Monster'}),
 c('Ash Blossom & Joyous Spring',{categories:['hand_trap']}),
 c('Crackle Blitzclique',{categories:['hand_trap']}),
 c('Whisker Blitzclique',{categories:['hand_trap']}),
 c('Angelechy Opening to e4',{type:'Trap Card',categories:['hand_trap']}),
 c('Triple Tactics Talent',{type:'Spell Card'}),
 c('Mystical Space Typhoon',{type:'Spell Card'}),
 c('Called by the Grave',{type:'Spell Card'}),
 c('Mystic Mine',{type:'Spell Card'}),
 c('Dark Magician',{type:'Normal Monster'}),
 c('Blue-Eyes White Dragon',{type:'Normal Monster'}),
 c('Stardust Dragon',{type:'Synchro Monster'}),
 c('Elder Entity Norden',{type:'Fusion Monster'}),
 c('Solemn Judgment',{type:'Trap Card'})
];
const cards=new Map(library.map(x=>[x.key,x]));
const newD=()=>L.newDeck('Test');
t('Phase 1 TCG list contains 256 entries',()=>assert.equal(Object.values(rules.official_tcg.status_lists).reduce((sum,a)=>sum+a.length,0),256));
t('Phase 1 custom Raigeki limited 1',()=>assert.equal(status(cards.get('raigeki')).limit,1));
t('Habakiri TCG Forbidden overrides CNR limited',()=>assert.equal(status(cards.get(L.nameKey('Ame no Habakiri no Mitsurugi'))).limit,0));
t('Triple Tactics Talent TCG Forbidden overrides CNR limited',()=>assert.equal(status(cards.get(L.nameKey('Triple Tactics Talent'))).limit,0));
t('Called by the Grave officially Forbidden',()=>assert.equal(status(cards.get(L.nameKey('Called by the Grave'))).status,'BANNED'));
t('Mystical Space Typhoon CNR limited 1',()=>assert.equal(status(cards.get(L.nameKey('Mystical Space Typhoon'))).limit,1));
t('Link Monster structurally banned',()=>assert.equal(status(cards.get(L.nameKey('Decode Talker'))).status,'BANNED'));
t('Pendulum structurally banned',()=>assert.equal(status(cards.get(L.nameKey('Odd-Eyes Pendulum Dragon'))).status,'BANNED'));
t('Hand trap from vetted list banned',()=>assert.equal(status(cards.get(L.nameKey('Ash Blossom & Joyous Spring'))).status,'BANNED'));
for(const name of ['Crackle Blitzclique','Whisker Blitzclique','Angelechy Opening to e4'])t(name+' bypasses ONLY hand trap CNR category',()=>assert.equal(status(cards.get(L.nameKey(name))).status,'LEGAL'));
t('Exception does not bypass another custom named prohibition',()=>{const p=structuredClone(rules);p.cnr.forbidden_named.push('Crackle Blitzclique');assert.equal(L.checkCard(cards.get('crackle blitzclique'),L.createIndex(p)).status,'BANNED');});
t('Exception does not bypass TCG prohibition',()=>{const p=structuredClone(rules);p.official_tcg.status_lists.Forbidden.push('Whisker Blitzclique');assert.equal(L.checkCard(cards.get('whisker blitzclique'),L.createIndex(p)).status,'BANNED');});
t('Unreviewed card is REVIEW, not LEGAL',()=>assert.equal(status(c('Unknown Partner',{reviewed:false})).status,'REVIEW'));
t('Unknown TCG release is REVIEW',()=>assert.equal(status(c('Unknown Partner',{released:null})).status,'REVIEW'));
t('TCG release after cutoff is banned',()=>assert.equal(status(c('Future Card',{tcg_date:'2026-10-22'})).status,'BANNED'));
t('Future-only TCG release explicitly false is banned',()=>assert.equal(status(c('Future Card',{released:false})).status,'BANNED'));
t('Unknown ID causes REVIEW',()=>assert.equal(status(c('Unknown ID',{id:null})).status,'REVIEW'));
t('Unknown card absent causes REVIEW',()=>assert.equal(status(null).status,'REVIEW'));
t('Normal Link-related annotation forbidden',()=>assert.equal(status(c('Link Support',{type:'Spell Card',categories:['link_related']})).status,'BANNED'));
t('Pure Spell not automatically Link related by card text',()=>assert.equal(status(c('Word Link',{type:'Spell Card',desc:'Link two cards together'})).status,'LEGAL'));
t('Spells in Main, Fusion in Extra',()=>{assert.equal(L.cardZone(c('Sample',{type:'Spell Card'})),'main');assert.equal(L.cardZone(c('Sample',{type:'Fusion Monster'})),'extra');});
t('Tokens are forbidden',()=>assert.equal(status(c('Token',{type:'Token'})).status,'BANNED'));
t('Deck under 40 fails validation',()=>{const d=newD();L.editQty(d,'main','dark magician',3);assert.equal(L.auditDeck(d,cards,idx).status,'ILLEGAL');});
t('40 verified legal monsters passes',()=>{const d=newD();const arr=[];for(let i=0;i<40;i++){const ob=c('Vanilla '+i,{id:2000+i,type:'Normal Monster'});arr.push(ob);L.editQty(d,'main',ob.key,1);}assert.equal(L.auditDeck(d,new Map(arr.map(x=>[x.key,x])),idx).status,'LEGAL');});
t('Extra Deck >20 fails',()=>{const d=newD();const arr=[];for(let i=0;i<42;i++){const ob=c('Plain '+i,{id:5000+i,type:'Normal Monster'});arr.push(ob);L.editQty(d,'main',ob.key,1);}L.editQty(d,'extra','stardust dragon',21);const cm=new Map([...arr,...library].map(x=>[x.key,x]));assert.ok(L.auditDeck(d,cm,idx).errors.some(s=>s.includes('maximum 20')));});
t('Side Deck is forbidden',()=>{const d=newD();L.editQty(d,'side','dark magician',1);assert.ok(L.auditDeck(d,cards,idx).errors.some(s=>s.includes('Side Deck')));});
t('Main/Extra zone mistakes rejected',()=>{const d=newD();L.editQty(d,'extra','dark magician',1);assert.ok(L.auditDeck(d,cards,idx).errors.some(s=>s.includes('wrong zone')));});
t('Named limit checks 2 Raigeki',()=>{const d=newD();L.editQty(d,'main','raigeki',2);assert.ok(L.auditDeck(d,cards,idx).errors.some(s=>s.includes('2 copies, allowed 1')));});
t('Max 3 per card enforced',()=>{const d=newD();L.editQty(d,'main','dark magician',4);assert.ok(L.auditDeck(d,cards,idx).errors.some(s=>s.includes('4 copies, allowed 3')));});
t('Counting duplicates across sections enforces cap',()=>{const d=newD();L.editQty(d,'main','dark magician',3);L.editQty(d,'side','dark magician',1);assert.ok(L.auditDeck(d,cards,idx).errors.some(s=>s.includes('4 copies, allowed 3')));});
t('Imported unknown ID remains counted in deck',()=>{const d=L.deckFromIds({main:[123,123,456],extra:[],side:[]},new Map());assert.equal(L.sectionCount(d.sections.main),3);assert.equal(d.sections.main.length,2);assert.equal(L.auditDeck(d,new Map(),idx).status,'ILLEGAL');});
t('Import YDK with categories',()=>{const deck=L.parseDeckText('#created by demo\n#main\n123\n123\n#extra\n456\n!side\n789\n');assert.deepEqual(deck,{main:[123,123],extra:[456],side:[789]});});
t('Import YDKE empty sections',()=>{const deck=L.parseDeckText('ydke://!!!');assert.deepEqual(deck,{main:[],extra:[],side:[]});});
t('YDKE roundtrip encodes little-endian card IDs',()=>{const d=L.newDeck();const a=c('Some Card',{id:46986414});const b=c('Some Extra',{id:15480588,type:'Fusion Monster'});const cat=new Map([a,b].map(x=>[x.key,x]));L.editQty(d,'main',a.key,3);L.editQty(d,'extra',b.key,1);assert.deepEqual(L.parseDeckText(L.toYDKE(d,cat)),{main:[46986414,46986414,46986414],extra:[15480588],side:[]});});
t('YDK roundtrip',()=>{const d=L.newDeck();const a=c('Some Card',{id:46986414});const cat=new Map([[a.key,a]]);L.editQty(d,'main',a.key,2);assert.deepEqual(L.parseDeckText(L.toYDK(d,cat)),{main:[46986414,46986414],extra:[],side:[]});});
t('YDK export refuses unknown passcode',()=>{const d=newD();L.editQty(d,'main','dark magician',1);assert.throws(()=>L.toYDK(d,new Map([['dark magician',c('Dark Magician',{id:null})]])),/passcode/);});
t('YDK parser rejects malformed IDs',()=>assert.throws(()=>L.parseDeckText('#main\nnot-id\n'),/Unrecognized/));
t('YDKE parser rejects broken ID bytes',()=>assert.throws(()=>L.parseDeckText('ydke://AQ==!!!'),/Malformed/));
t('YDKE parser rejects malformed delimiters',()=>assert.throws(()=>L.parseDeckText('ydke://abc!'),/Invalid/));
t('Name aliases normalize correctly',()=>assert.equal(idx.canonical('MST'),idx.canonical('Mystical Space Typhoon')));
t('Card API normalization no review on uncurated',()=>{const a=L.apiToCard({id:23,name:'Example',type:'Effect Monster',desc:'Text'},new Map(),new Map(),rules.card_pool.include_released_through);assert.equal(a.reviewed,false);assert.equal(a.released,null);});
t('Set metadata known release is inferred',()=>{const a=L.apiToCard({id:23,name:'Example',type:'Effect Monster',card_sets:[{set_name:'Sample'}]},new Map(),new Map([['Sample','2026-01-02']]),rules.card_pool.include_released_through);assert.equal(a.released,true);});
t('Newer release is flagged post cutoff',()=>{const a=L.apiToCard({id:23,name:'Example',type:'Effect Monster',card_sets:[{set_name:'Future'}]},new Map(),new Map([['Future','2027-01-02']]),rules.card_pool.include_released_through);assert.equal(a.released,false);});
t('Phase 1 seed has 17 records',()=>assert.equal(seed.cards.length,17));
t('Deck normalizer drops invalid entries',()=>{const d=L.normalizeDeck({sections:{main:[{key:'abc',qty:1},{key:'bad',qty:-1}]}});assert.equal(d.sections.main.length,1);});
t('No hard-coded external image requests',()=>{const s=fs.readFileSync(path.join(__dirname,'../app.js'),'utf8');assert.equal(s.includes('images.ygoprodeck.com'),false);});
console.log(`\n${total}/${total} logic checks passed.`);
